# 08 — RETENTION ENGINE
## The Good Inside mechanics that keep members subscribed, built in

Subscription products live or die on retention. Good Inside keeps parents
paying through rhythm, freshness, progress and listening. This doc makes every
one of those mechanics an explicit build requirement.

---

## 1. THE WEEKLY RHYTHM (the core habit loop)

Good Inside: "This Week's Moment" newsletter + weekly content drops.
Guided Childhood equivalent, all already in the data model:

```
Monday 09:00    Weekly 3-action plan lands (dashboard + notification + email)
Midweek         One conversation starter, stage-specific
Weekly          Wellbeing tracker check-in (5 questions, trend chart)
Sunday          "This Week on the Pathway" email: one insight, one script,
                one thing in the news decoded for parents
```

The member must feel the platform moves every week even if they never log in.
The Sunday email is content marketing AND retention in one send.

## 2. MONTHLY FRESHNESS (the "always growing" signal)

```
- "New this month" panel on the dashboard, fed by ai_curriculum_updates:
  new scripts, new research decoded, UK guidance changes, platform features.
- Monthly member email from Justin: what was added, what is coming, one
  member question answered. Personal, never corporate.
- Each month at least one new script or lesson ships. The 17 scripts grow.
```

## 3. PROGRESS AND MILESTONES (sunk value)

```
- streak_weeks on tracker: visible streak, gentle not gamified.
- Pathway progress bar: weeks on pathway, actions completed, stage position.
- Stage transitions are celebrated: "Your child moves to Stage 4 this
  September. Here is what changes." A renewal moment, not a churn moment.
- Family agreement review dates trigger a revisit flow each term.
```

## 4. FEEDBACK PROMPTS (the listening loop)

```
- Thumbs on every DiGi response (digi_questions.rating) — exists.
- "Did this script help?" after script use (script_views.marked_helpful).
- Quarterly 3-question member pulse: what helped most, what is missing,
  one thing to change. Results feed the monthly Justin email.
- Founder members: standing invite to shape the roadmap. Their questions
  visibly become features ("You asked, we built").
```

## 5. CANCELLATION SAVE FLOW (required, Week 4 with Stripe)

```
On cancel click, in order:
1. Ask why (4 options + free text) — log to churn_reasons table.
2. Offer pause: 1 or 2 months frozen, data kept, no charge.
3. If price: offer annual (£99, saves £57) — never discount monthly.
4. If cancelled anyway: warm exit, keep free tier active, start win-back.
```

## 6. WIN-BACK SEQUENCE

```
Day 7    "Your child's pathway is saved exactly where you left it."
Day 30   What is new since they left + one free script.
Stage    When their child's age crosses a stage boundary: "Stage 4 starts
         now. This is the window the research talks about." (highest
         converting moment, fully automated from child age_band)
```

## 7. WHY THIS WORKS HERE ESPECIALLY

Good Inside retains because parenting needs evolve. Ours is stronger: the
pathway has a built-in 12-year arc. A child who is 8 today gives this member
8 more years of stage transitions, each one a fresh reason to stay. Surface
that arc constantly: "the pathway grows with them."

## DATABASE ADDITIONS

```sql
create table churn_reasons (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  reason text, detail text, saved_by text,  -- 'pause','annual',null
  created_at timestamptz default now()
);

create table member_pulse (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id),
  quarter text, helped_most text, missing text, change_one_thing text,
  created_at timestamptz default now()
);
```

## BUILD SCHEDULE

```
Week 2   Weekly rhythm (plan + tracker + streaks), progress bar
Week 3   Sunday email, "New this month" panel, feedback prompts
Week 4   Cancellation save flow + pause (with Stripe work)
Week 5   Win-back sequence, stage-transition automation
```
