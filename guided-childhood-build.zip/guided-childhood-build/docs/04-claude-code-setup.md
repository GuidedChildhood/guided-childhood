# HOW TO BUILD THIS WITH CLAUDE CODE
## Step-by-Step Setup Guide for Justin

---

## What You Need Before Starting

1. **GitHub account** — github.com/GuidedChildhood/guided-childhood (already exists)
2. **Vercel account** — vercel.com (already exists)
3. **Supabase account** — supabase.com (create free account)
4. **Stripe account** — stripe.com (create free account)
5. **Anthropic API key** — console.anthropic.com (create account, get key)
6. **Node.js installed** — nodejs.org (download LTS version)

---

## Step 1 — Install Claude Code

Open Terminal (Mac) or Command Prompt (Windows) and run:

```bash
npm install -g @anthropic-ai/claude-code
```

Verify it worked:
```bash
claude --version
```

---

## Step 2 — Create the Next.js project

In Terminal, navigate to where you want the project:

```bash
cd ~/Documents
npx create-next-app@latest guided-childhood --typescript --tailwind --app --src-dir
cd guided-childhood
```

---

## Step 3 — Copy this build folder into the project

Copy the entire `guided-childhood-build` folder into the root of your Next.js project. 

The structure should look like:
```
guided-childhood/
  guided-childhood-build/    ← the spec folder
    README.md
    docs/
    digi/
    curriculum/
    scripts/
    research/
    schools/
  src/
  public/
  package.json
  ...
```

---

## Step 4 — Set up Supabase

Go to supabase.com → New Project → name it `guided-childhood`

Once created:
1. Go to Settings → API
2. Copy your Project URL and anon key

Go to SQL Editor and run the entire contents of:
`guided-childhood-build/docs/02-database.md`
(copy everything inside the ```sql blocks)

---

## Step 5 — Set up Stripe

Go to stripe.com → Dashboard → Products

Create these products:
```
Name: Guided Childhood Founder Monthly
Price: £7.99/month recurring
Metadata: tier=founder

Name: Guided Childhood Standard Monthly  
Price: £12.99/month recurring
Metadata: tier=standard

Name: Guided Childhood Annual
Price: £99/year recurring
Metadata: tier=annual

Name: School Licence Standard
Price: £299/year recurring
Metadata: tier=school_standard

Name: School Licence Large
Price: £499/year recurring
Metadata: tier=school_large
```

Copy the price IDs for each.

---

## Step 6 — Create environment variables

In your project root create a file called `.env.local`:

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_KEY=your_supabase_service_key
ANTHROPIC_API_KEY=your_anthropic_key
STRIPE_SECRET_KEY=your_stripe_secret_key
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
STRIPE_WEBHOOK_SECRET=add_after_webhook_setup
NEXT_PUBLIC_APP_URL=http://localhost:3000

STRIPE_FOUNDER_PRICE_ID=
STRIPE_STANDARD_PRICE_ID=
STRIPE_ANNUAL_PRICE_ID=
STRIPE_SCHOOL_STANDARD_PRICE_ID=
STRIPE_SCHOOL_LARGE_PRICE_ID=

FOUNDER_MEMBER_LIMIT=50
```

---

## Step 7 — Start Claude Code

In Terminal, from your project root:

```bash
claude
```

Claude Code opens. Now paste this as your first message:

```
Read the file guided-childhood-build/README.md and then all files 
in guided-childhood-build/docs/ before we start.

I am building the Guided Childhood platform — a digital parenting 
pathway for children aged 4-16. This is Week 1 of the build.

Week 1 deliverables:
1. Install dependencies: @supabase/supabase-js, @supabase/auth-helpers-nextjs, 
   stripe, @anthropic-ai/sdk
2. Set up Supabase client (src/lib/supabase/)
3. Set up auth middleware (middleware.ts)
4. Build login and signup pages with email + password
5. Build the onboarding flow (3 questions)
6. Rebuild the homepage from the existing index.html — same design, 
   same colours, same content but as a Next.js page
7. Deploy to Vercel

Use the colour system and typography specified in the README.
Use the frontend-design skill principles — distinctive, warm, editorial.
Do not use generic AI web design patterns.
```

---

## Step 8 — How to work with Claude Code

Claude Code reads your files, writes code, and runs commands in your terminal.

**Each week, start a new Claude Code session and say:**
```
We are continuing the Guided Childhood build. 
Read guided-childhood-build/README.md to recap.
This week is Week [number]. The deliverables are: [paste from README]
```

**When Claude Code writes something you want to change:**
```
Change [specific thing] to [what you want]
Keep everything else the same
```

**When something breaks:**
```
This is the error: [paste error]
This is the file it is in: [paste code]
Fix it
```

**When you want to add something new:**
```
Add [feature] to [location in the app]
It should work like: [describe]
Reference the research/philosophy in guided-childhood-build/research/ 
to make sure it aligns
```

---

## Step 9 — Connect to GitHub

In Claude Code or Terminal:

```bash
git remote add origin https://github.com/GuidedChildhood/guided-childhood.git
git branch -M main
git push -u origin main
```

Vercel auto-deploys on every push. Your `.env.local` values need to be added to Vercel too:
- Go to vercel.com → Project → Settings → Environment Variables
- Add every variable from `.env.local`

---

## Step 10 — Verify before going live

Checklist before each weekly deploy:

```
[ ] Auth works — can sign up, log in, log out
[ ] Onboarding assigns correct stage
[ ] DiGi responds correctly for the stage
[ ] Rate limiting works (free tier: 3 messages/day)
[ ] Paywall shows on paid content for free users
[ ] Stripe checkout works (use test mode first)
[ ] All scripts display correctly
[ ] Wellbeing tracker saves to Supabase
[ ] Mobile layout correct
[ ] No console errors
```

---

## DiGi — How to Update the System Prompt

DiGi's system prompt lives in `src/lib/anthropic/digi-system-prompt.ts`

To update DiGi's behaviour:
1. Open the file in any text editor or in GitHub
2. Change the relevant section
3. Save and commit
4. Vercel redeploys automatically in 60 seconds

To add a new AI curriculum update without redeploying:
1. Log in to guidedchildhood.com/admin
2. Click "Add update"
3. Write the update, select which stages it applies to
4. Click Publish
5. DiGi includes it in responses immediately

---

## Design Principles — Remind Claude Code of These

When Claude Code produces something that looks generic, paste this:

```
This design does not match the Guided Childhood brand.

Colour system:
--cream: #FDFCF8 (near-white warm background)
--green: #8FBF9F (primary brand, sage green)
--coral: #C96B47 (scripts and alerts)
--gold: #D4A843 (CTA buttons)
--ink: #1C1A14 (primary text)

Typography:
- Fraunces (serif) for headings and display text
- DM Sans for body and UI

The design benchmark is goodinside.com.
Warm. Editorial. Clean. Personal. Not corporate.
No generic AI web design patterns.
No purple gradients. No Inter font.
```

---

## Files to Keep Updated as the Platform Grows

As you discover new research, add scripts, or update DiGi's approach:

```
Update this file:                    When:
digi/01-philosophy.md                New research or DiGi behaviour change
scripts/all-17-scripts.md            New scripts added
research/01-philosophy.md            New research publications
schools/01-school-version.md         New modules or pilot updates
docs/03-routes.md                    New pages added
```

These files are DiGi's source of truth. Keep them current and Claude Code builds correctly.
