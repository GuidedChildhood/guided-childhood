# 03 — ROUTES & PAGES

## Public Routes (no auth required)

```
/                       Homepage
/how-it-works           TRUST framework + five stages
/schools                School version landing page
/pricing                Standalone pricing
/about                  Justin's story
/starter-pack           Interactive starter check = onboarding (see docs/06-starter-pack-funnel.md)
/school-pack            Teacher starter pack: sample lesson + pilot CTA (see docs/06)
/digitalwellbeing       Digital Health Checker tool
/login                  Email + password login
/signup                 Email + password signup
/forgot-password        Password reset
```

## Onboarding (auth required, redirects here after signup)

```
/onboarding             3-question flow → stage assignment
```

## Dashboard — Parent (auth + profile complete required)

```
/dashboard              Home — stage card, weekly actions, DiGi prompt
/dashboard/digi         Full DiGi conversation interface
/dashboard/stage        Current stage detail view
/dashboard/scripts      All 17 scripts (paid) or 3 (free)
/dashboard/tracker      Weekly wellbeing check-in
/dashboard/curriculum   Stage lessons
/dashboard/agreement    Family agreement builder
/dashboard/children     Manage children (add, switch)
/dashboard/wellbeing    Mental health checker history + link
/dashboard/settings     Account, notifications, billing
/dashboard/upgrade      Paywall / upgrade page
```

## Educator Routes (auth + educator role required)

```
/educator               School dashboard home
/educator/scheme        Full scheme of work (21 modules)
/educator/cpd           CPD module for staff
/educator/safeguarding  DSL view — flagged concerns
/educator/assemblies    Assembly packs download
/educator/parents       Parent communication tools
/educator/pilot         Pilot scheme status
/educator/settings      School profile management
```

## Admin Routes (auth + admin role required)

```
/admin                  Overview — users, conversions, flags
/admin/updates          Add AI curriculum updates
/admin/users            User management
/admin/schools          School licences
/admin/digi             DiGi quality review — low-rated responses
```

## API Routes

```
/api/digi               POST — send message to DiGi
/api/digi/history       GET — conversation history
/api/tracker            POST — submit weekly check-in
/api/tracker/history    GET — tracker history for child
/api/stripe/checkout    POST — create Stripe checkout session
/api/stripe/webhook     POST — handle Stripe events
/api/school/pilot       POST — submit pilot scheme request
/api/admin/updates      POST/PUT — manage curriculum updates
/api/wellbeing/sync     POST — sync mental health checker data
```

---

## Key Page Specifications

### /dashboard (Home)

Layout: three sections stacked

**Section 1 — Stage Card**
- Child name + stage badge
- Stage name, KS, Year Group
- Device recommendation
- Progress bar (weeks on pathway)

**Section 2 — This Week's Actions**
- 3 action cards
- Tick off as done
- DiGi tip in gold box
- "2 of 3 done" progress

**Section 3 — DiGi Quick Access**
- "Ask DiGi anything" input
- Last 3 conversation snippets
- Link to full conversation
- Daily message count (free: 3/day shown)

---

### /dashboard/digi (DiGi Full Interface)

Chat interface similar to the mini app but full-screen.
Persistent conversation history.
Suggested prompts by stage.
Topic categories shown on each response.
Thumbs up/down rating on each response.
Free tier: 3 messages/day shown clearly with upgrade prompt.
Paid tier: unlimited.

Suggested prompts vary by stage:
```
Stage 3 examples:
  "Her mood drops after Instagram — what do I say tonight?"
  "My son won't stop gaming — is this a problem?"
  "How do I introduce the bedroom rule without a fight?"
  "She says everyone else has TikTok"
  "I found something on his phone — how do I start this conversation?"
```

---

### /dashboard/scripts

Grid of all 17 scripts.
Each card shows: number, title, stage badge, context line.
Click to expand: SAY THIS (green) / NOT THIS (coral) / WHY IT WORKS (gold).
Mark as helpful. Save favourite.
Search by topic.
Free tier shows 3 scripts with paywall on the rest.

---

### /dashboard/tracker

Weekly check-in form.
5 questions + optional stage-specific questions.
Submit → DiGi responds with a personalised note.
Trend chart over time.
Concern flagging with referral suggestion if threshold met.

---

### /schools (Marketing page)

Sections:
1. Hero — "A digital literacy curriculum your school can actually use"
2. What it covers — 21 modules, EYFS to Sixth Form
3. Statutory alignment — Online Safety Act, RSE, EfCW, DfE AI
4. Oak National Academy alignment
5. How it works for schools
6. CPD for staff
7. DSL safeguarding view
8. Parent-school connection
9. Pricing — £299/yr and £499/yr
10. **Pilot scheme CTA** — "Request a pilot and meeting"

**Pilot CTA Section (prominent):**
```
Headline: "Start with a free pilot scheme"
Body: "We work with a small number of schools each term to 
       implement Guided Childhood with full support. No commitment 
       required. One conversation to see if it fits."
Button: "Request a pilot meeting" → /educator/pilot or modal form
Form: School name, your role, email, best time to talk
Confirmation: "We will be in touch within 48 hours"
```

---

### /pricing

Three cards:
```
Free
  - Onboarding + stage card
  - DiGi: 3 questions/day
  - 3 scripts
  - Stage 1 curriculum only
  CTA: Get started free

Standard — £12.99/month
  - Everything free +
  - All 5 stages
  - Unlimited DiGi
  - All 17 scripts
  - Wellbeing tracker
  - Mental health checker history
  - Family agreement builder
  CTA: Start your pathway

Annual — £99/year (save £57)
  - Everything Standard
  CTA: Best value

School — from £299/year
  - Staff dashboard
  - Full scheme of work
  - DSL view
  - Parent connection
  CTA: Request a pilot
```

Founder rate card (shown to waitlist members only):
```
Founder Rate — £7.99/month for life
First 50 members only
Everything Standard
CTA: Claim founder rate (48-hour window on launch)
```
