# 06 — STARTER PACK FUNNEL (PRE-PAYWALL FRONT DOOR)
## LABELLED WORKSTREAM: Starter pack = free tier entry = onboarding

This document locks in the growth architecture decision: the starter pack is not
a download. It is the first pre-paywall part of the service itself. One flow,
three jobs: lead capture, onboarding, and stage assignment.

---

## THE PRINCIPLE

Collapse the lead magnet into the product. The parent uses the product before
being asked for anything (Duolingo / Canva / Good Inside model). The signup gate
sits AFTER the aha moment, framed as saving something that is already theirs:
"Save your child's pathway." Email capture after value converts 3 to 5x better
than before it.

## THE PARENT FUNNEL

```
Social post / search
  → /starter-pack (no signup, instant)
  → 3 questions (child age, main challenge, how parent feels)
  → personalised result: stage card + script + one action + warning signs  ← AHA
  → "Save your child's pathway" gate
       INTERIM (now):       Mailchimp parents landing page
       PLATFORM (Week 1+):  free account creation (Supabase auth)
  → free tier (stage card, 3 DiGi messages/day, 3 scripts, Stage 1 curriculum)
  → 14-day email nurture sequence (already built)
  → founder rate paywall (£7.99 lifetime, first 50) → standard £12.99
```

CRITICAL: the 3 starter questions ARE the platform onboarding questions.
A parent who completes the starter pack has already onboarded. When auth is
built, the starter answers are passed into the signup so they never repeat them.
Store answers in localStorage interim; write to profiles.onboarding_answers
on account creation.

## THE SCHOOL FUNNEL (PILOT-LED, NOT PRODUCT-LED)

B2B education does not impulse-subscribe. The teacher evaluates, then advocates
internally. The free thing for schools is the PILOT, not a free tier.

```
/teachers section or /school-pack
  → complete sample lesson (Module 9) + assembly outline + statutory alignment
  → "Request a pilot meeting" CTA
       INTERIM (now):       Mailchimp school landing page
       PLATFORM (Week 5+):  pilot request form → school_profiles table
  → 48-hour response → 30-min call → free one-term pilot → paid licence
```

The statutory alignment document is the conversion asset: it is what the DSL
shows the head and governors. Always include it in the pack.

## CURRENT STATIC IMPLEMENTATION (LIVE NOW)

Two static pages exist in the repo and must be preserved through the
Next.js migration:

```
/starter-pack   starter-pack.html   Parent interactive check.
                                    Deterministic personalisation (stage from
                                    age; templated guidance from challenge +
                                    feeling). No API calls, no keys exposed.
/school-pack    school-pack.html    Sample lesson + assembly + alignment +
                                    pilot CTA.
```

Both use the checker design system (see README colour section).

## WEEK 1+ MIGRATION RULES

1. /starter-pack becomes a Next.js page. Same 3 questions, same result layout.
2. Replace the templated guidance message with a real DiGi (claude-fable-5)
   response server-side. Keep the deterministic fallback for API failures.
3. Replace the Mailchimp gate with account creation: "Save your child's
   pathway" creates the free-tier account and writes onboarding_answers.
4. After signup, land on /dashboard with the stage already assigned. Zero
   repeated questions.
5. /school-pack becomes the gated teacher pack: school email address unlocks
   the downloadable sample module PDF + assembly deck, then routes to the
   pilot request form.
6. The PDF starter pack remains the Email 1 deliverable for the existing
   Mailchimp list. Do not delete it. New traffic routes to /starter-pack.

## METRICS THAT MATTER

```
starter_starts          visits that begin question 1
starter_completes       reached the result screen        (target >70% of starts)
save_rate               clicked "Save my pathway"        (target >25% of completes)
activation              free account + 1 DiGi message    (post-launch)
paid_conversion         free → founder/standard          (target 5-10% in 30 days)
pilot_requests          school form submissions
```

Log starter answers (anonymous, aggregated) even pre-auth: the distribution of
challenges by age band is product intelligence and content fuel.
