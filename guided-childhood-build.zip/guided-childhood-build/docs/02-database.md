# 02 — DATABASE SCHEMA

## Supabase Tables

Run this SQL in Supabase SQL editor exactly as written.

---

```sql
-- ═══════════════════════════════════════════════════════════
-- PROFILES — extends Supabase auth.users
-- ═══════════════════════════════════════════════════════════

create table profiles (
  id                    uuid references auth.users primary key,
  email                 text not null,
  full_name             text,
  role                  text default 'parent' check (role in ('parent','educator','admin')),

  -- Subscription
  stripe_customer_id    text unique,
  subscription_status   text default 'free' check (subscription_status in ('free','active','cancelled','past_due')),
  subscription_tier     text check (subscription_tier in ('founder','standard','annual','school_licence','school_large')),
  subscription_end      timestamptz,
  is_founder            boolean default false,

  -- Onboarding
  onboarding_complete   boolean default false,
  onboarding_answers    jsonb,          -- { childAge, mainChallenge, parentFeel }

  -- Preferences
  notification_email    boolean default true,
  notification_push     boolean default false,
  notification_whatsapp boolean default false,
  whatsapp_number       text,

  created_at            timestamptz default now(),
  updated_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- CHILDREN — one parent can have multiple children
-- ═══════════════════════════════════════════════════════════

create table children (
  id                    uuid primary key default gen_random_uuid(),
  parent_id             uuid references profiles(id) on delete cascade,
  name                  text not null,            -- first name only
  age_band              text not null,            -- '4-7','8-10','11-13','13-15','16+'
  stage_id              int not null check (stage_id between 1 and 5),
  year_group            text,                     -- 'Year 6' etc
  key_stage             text,                     -- 'KS2' etc

  -- Optional vulnerability flags (all opt-in, private)
  gender                text,                     -- optional, for Orben stage 3 targeting
  neurodivergent_flag   boolean default false,
  mental_health_flag    boolean default false,
  harassment_flag       boolean default false,

  -- Progress
  current_unit          int default 1,
  actions_this_week     int default 0,
  streak_weeks          int default 0,
  last_active           timestamptz,

  is_primary            boolean default true,     -- first child added
  created_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- DIGI CONVERSATIONS
-- ═══════════════════════════════════════════════════════════

create table digi_conversations (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid references profiles(id) on delete cascade,
  child_id              uuid references children(id),

  messages              jsonb not null default '[]',  -- array of {role,content,timestamp}
  message_count         int default 0,

  -- Rate limiting
  messages_today        int default 0,
  last_message_date     date default current_date,

  -- Quality
  last_rating           int,                          -- 1-5 thumbs from parent
  flagged               boolean default false,

  created_at            timestamptz default now(),
  updated_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- DIGI QUESTIONS LOG — captures all questions for learning
-- ═══════════════════════════════════════════════════════════

create table digi_questions (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid references profiles(id),
  child_id              uuid references children(id),
  stage_id              int,

  question              text not null,
  response              text not null,
  topic_category        text,     -- 'social_media','bedtime','algorithm','safety' etc
  is_off_topic          boolean default false,
  redirected_to         text,     -- if off-topic, what was it redirected to

  rating                int,      -- parent rating 1-5
  helpful               boolean,

  created_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- WELLBEING TRACKER
-- ═══════════════════════════════════════════════════════════

create table wellbeing_checks (
  id                    uuid primary key default gen_random_uuid(),
  child_id              uuid references children(id) on delete cascade,
  parent_id             uuid references profiles(id),
  week_start            date not null,

  -- Core scores 1-5
  mood_score            int check (mood_score between 1 and 5),
  sleep_score           int check (sleep_score between 1 and 5),
  social_score          int check (social_score between 1 and 5),
  screen_mood_score     int check (screen_mood_score between 1 and 5),
  open_communication    int check (open_communication between 1 and 5),

  -- Optional stage-specific
  body_image_score      int check (body_image_score between 1 and 5),
  harassment_incidents  int default 0,

  -- Concern flags
  concern_level         text default 'none' check (concern_level in ('none','low','medium','high')),
  digi_flagged          boolean default false,
  referral_suggested    boolean default false,
  referral_note         text,

  notes                 text,
  created_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- SCRIPT INTERACTIONS — track which scripts parents use
-- ═══════════════════════════════════════════════════════════

create table script_views (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid references profiles(id),
  script_id             int not null,
  script_title          text,
  stage_id              int,
  viewed_at             timestamptz default now(),
  marked_helpful        boolean
);

-- ═══════════════════════════════════════════════════════════
-- FAMILY AGREEMENT
-- ═══════════════════════════════════════════════════════════

create table family_agreements (
  id                    uuid primary key default gen_random_uuid(),
  family_id             uuid references profiles(id),
  version               int default 1,
  agreed_date           date,
  review_date           date,

  -- Agreement sections (filled by family)
  family_values         text,
  bedroom_rule_time     text,
  bedroom_rule_location text,
  social_media_age      text,
  when_things_go_wrong  text,
  extra_agreements      text,

  signed_by_parent      boolean default false,
  signed_by_child       boolean default false,

  created_at            timestamptz default now(),
  updated_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- MENTAL HEALTH CHECKER LINK
-- ═══════════════════════════════════════════════════════════

create table wellbeing_tool_history (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid references profiles(id),
  child_id              uuid references children(id),

  check_date            date not null,
  platform              text,          -- 'youtube','tiktok','instagram'
  concern_level         text,
  flags_raised          jsonb,         -- array of flag types
  priority_actions      jsonb,         -- 5 actions returned
  report_summary        text,

  digi_notified         boolean default false,
  referral_made         boolean default false,

  created_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- CURRICULUM PROGRESS
-- ═══════════════════════════════════════════════════════════

create table curriculum_progress (
  id                    uuid primary key default gen_random_uuid(),
  child_id              uuid references children(id),
  parent_id             uuid references profiles(id),

  stage_id              int not null,
  unit_id               int not null,
  lesson_id             int not null,

  completed             boolean default false,
  completed_at          timestamptz,
  notes                 text,

  created_at            timestamptz default now(),
  unique(child_id, stage_id, unit_id, lesson_id)
);

-- ═══════════════════════════════════════════════════════════
-- SCHOOL PROFILES
-- ═══════════════════════════════════════════════════════════

create table school_profiles (
  id                    uuid primary key default gen_random_uuid(),
  admin_id              uuid references profiles(id),

  school_name           text not null,
  school_email          text not null unique,
  school_type           text,     -- 'primary','secondary','all-through','special'
  local_authority       text,
  postcode              text,
  pupil_count           int,

  -- DSL details
  dsl_name              text,
  dsl_email             text,
  pshe_lead_name        text,

  -- Pilot
  pilot_requested       boolean default false,
  pilot_request_date    timestamptz,
  pilot_status          text default 'none',   -- 'none','requested','scheduled','active'
  pilot_meeting_date    timestamptz,
  pilot_notes           text,

  -- Licence
  licence_tier          text,
  licence_start         date,
  licence_end           date,

  created_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- AI CURRICULUM UPDATES — Justin adds these from admin panel
-- ═══════════════════════════════════════════════════════════

create table ai_curriculum_updates (
  id                    uuid primary key default gen_random_uuid(),
  title                 text not null,
  content               text not null,
  applies_to_stages     int[] not null,    -- [1,2,3,4,5] or subset
  source                text,
  source_url            text,
  uk_legislation_ref    text,
  published             boolean default false,
  published_at          timestamptz,
  created_by            uuid references profiles(id),
  created_at            timestamptz default now()
);

-- ═══════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ═══════════════════════════════════════════════════════════

-- Enable RLS on all tables
alter table profiles enable row level security;
alter table children enable row level security;
alter table digi_conversations enable row level security;
alter table digi_questions enable row level security;
alter table wellbeing_checks enable row level security;
alter table script_views enable row level security;
alter table family_agreements enable row level security;
alter table wellbeing_tool_history enable row level security;
alter table curriculum_progress enable row level security;
alter table school_profiles enable row level security;

-- Profiles: users see only their own
create policy "users_own_profile" on profiles
  for all using (auth.uid() = id);

-- Children: parents see only their own children
create policy "parents_own_children" on children
  for all using (auth.uid() = parent_id);

-- DiGi: users see only their own conversations
create policy "users_own_digi" on digi_conversations
  for all using (auth.uid() = user_id);

-- Wellbeing: parents see only their own
create policy "parents_own_wellbeing" on wellbeing_checks
  for all using (auth.uid() = parent_id);

-- School: admin sees only their school
create policy "school_admin_own" on school_profiles
  for all using (auth.uid() = admin_id);

-- AI updates: everyone can read published
create policy "public_read_updates" on ai_curriculum_updates
  for select using (published = true);

-- ═══════════════════════════════════════════════════════════
-- FUNCTIONS
-- ═══════════════════════════════════════════════════════════

-- Auto-update profiles.updated_at
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger profiles_updated_at before update on profiles
  for each row execute function update_updated_at();

create trigger agreements_updated_at before update on family_agreements
  for each row execute function update_updated_at();
```
