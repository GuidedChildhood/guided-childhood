# 01 — ARCHITECTURE

## Stack

```
Frontend:   Next.js 14 (App Router)
Database:   Supabase (Postgres + Auth + Realtime)
Payments:   Stripe (subscriptions + one-time)
AI:         Anthropic API (DiGi — claude-fable-5)
Hosting:    Vercel (auto-deploy from GitHub)
Email:      Mailchimp (existing setup — do not replace)
Storage:    Supabase Storage (user uploads for wellbeing tool)
```

## Application Structure

```
/app
  /(marketing)          — Public pages, no auth required
    /page.tsx           — Homepage (rebuild from index.html)
    /how-it-works/      — TRUST framework deep dive
    /schools/           — School version landing
    /pricing/           — Standalone pricing
    /about/             — Justin's story
    /starter-pack/      — Mini app (existing React component)
    /digitalwellbeing/  — Wellbeing tool (existing)

  /(auth)               — Auth pages
    /login/             — Email + password login
    /signup/            — Email + password signup
    /forgot-password/   — Reset flow
    /onboarding/        — 3-question stage assignment

  /(dashboard)          — Protected, requires auth
    /dashboard/         — Parent home
    /dashboard/digi/    — DiGi full conversation
    /dashboard/stage/   — Current stage view
    /dashboard/scripts/ — All 17 scripts
    /dashboard/tracker/ — Wellbeing tracker
    /dashboard/agreement/ — Family agreement
    /dashboard/curriculum/ — Lessons
    /dashboard/wellbeing-history/ — Mental health checker link

  /(schools)            — Protected, school role
    /educator/          — School dashboard
    /educator/scheme/   — Scheme of work
    /educator/cpd/      — CPD module
    /educator/safeguarding/ — DSL view
    /educator/pilot/    — Pilot scheme request

  /(admin)              — Protected, admin role
    /admin/             — Admin dashboard
    /admin/updates/     — Add AI curriculum updates
    /admin/users/       — User management

/components
  /ui/                  — Design system components
  /digi/                — DiGi interface components
  /dashboard/           — Dashboard sections
  /marketing/           — Homepage sections
  /schools/             — School-specific components

/lib
  /supabase/            — Client, server, middleware
  /anthropic/           — DiGi API calls
  /stripe/              — Payment helpers
  /content/             — Stage data, scripts, curriculum

/middleware.ts          — Auth protection for routes
```

## Auth Flow

```
1. User visits /signup
2. Enters name, email, password
3. Supabase creates user
4. Redirect to /onboarding
5. 3 questions: child age, main challenge, how they feel
6. Stage assigned and stored in profiles table
7. Redirect to /dashboard
8. Free tier active immediately
9. Paywall shown when accessing paid content
```

## Two Roles

```
parent      — default role on signup
educator    — set when school email validated
admin       — set manually in Supabase
```

## Paywall Logic

```typescript
// Free tier — always accessible
- Onboarding
- Stage card view
- DiGi: 3 messages per day
- Stage 1 curriculum only
- 3 scripts (scripts 1, 3, 5)
- Wellbeing checker 1 use

// Paid tier — Stripe subscription required  
- All 5 stages
- Unlimited DiGi
- All 17 scripts
- Full curriculum
- Wellbeing tracker (weekly)
- Mental health checker history
- Family agreement builder
- Push notifications / alerts (Phase 2)
- WhatsApp alerts (Phase 2)

// School tier — separate Stripe price
- All parent features for staff
- Educator dashboard
- Full scheme of work
- DSL safeguarding view
- Parent-school connection
- Pilot scheme access
```

## Stripe Products to Create

```
prod_founder_monthly      £7.99/mo  — first 50 only, lifetime lock
prod_standard_monthly     £12.99/mo — standard parent
prod_annual               £99/yr    — standard annual
prod_school_licence       £299/yr   — school up to 300 pupils
prod_school_large         £499/yr   — school 300+
```

## Notification System (Phase 2 — Week 5+)

Alert types that fire based on time and context:

```
morning_before_school     07:00 Mon-Fri  — "One thing for this morning"
returning_home            15:30 Mon-Fri  — "They are about to be home"  
evening_device_time       18:00 daily    — "Evening device check"
bedtime_reminder          20:30 daily    — "Bedroom rule reminder"
weekly_checkin            Mon 09:00      — "This week's 3 actions"
tracker_concern           triggered      — "Your tracker flagged something"
stage_transition          triggered      — "Stage milestone approaching"
```

Delivery channels (in order of build priority):
1. In-app notifications (Week 2)
2. Email via Mailchimp (Week 3)
3. Push notifications via web push (Phase 2)
4. WhatsApp via Twilio (Phase 2 — paywall feature)

## Mental Health Checker Integration

```
/dashboard/wellbeing-history connects to digitalwellbeing tool
Shared Supabase user ID links records
Dashboard shows:
  - Last check date
  - Summary of flags (not raw data)
  - DiGi response based on history
  - Referral routing if concern threshold met
  - Link to full tool at guidedchildhood.com/digitalwellbeing
```
