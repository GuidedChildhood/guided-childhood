# 05 — LANDING PAGE UPDATE BRIEF (index.html)
## LABELLED WORKSTREAM: Homepage redesign + fixes
## Status: TO DO — can run before or alongside Week 1

This document is the single source of truth for updating the live homepage at
guidedchildhood.com (currently a static `index.html` in the repo root, served by Vercel).
This work can be done as a surgical update to the existing `index.html` — it does NOT
require the Next.js rebuild. When the Next.js homepage is built in Week 1, it inherits
everything in this brief.

---

## JOB 1 — Brand alignment with the Digital Health Checker tool

The homepage and the wellbeing tool (`/digitalwellbeing`) must look like one product.
The benchmark aesthetic is the health checker page plus goodinside.com:
warm, editorial, personal — NOT generic AI web design.

### Fonts (load via Google Fonts, replace whatever is currently loaded)

```html
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,300;0,400;0,700;1,300&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
```

```css
--serif: 'Fraunces', Georgia, serif;     /* ALL headings, display text, pull quotes */
--sans:  'DM Sans', Arial, sans-serif;   /* body, UI, buttons, labels */
```

Every `h1`–`h3` and the logo wordmark use Fraunces with `letter-spacing: -0.03em`.
Everything else uses DM Sans. No other fonts anywhere.

### Colour tokens (exact — replace the existing `:root` block)

```css
:root{
  --cream:      #FDFCF8;   /* page background */
  --cream-2:    #F7F4EB;   /* alternating sections */
  --cream-3:    #EEE8D0;   /* card surfaces, policy strip */
  --ink:        #1C1A14;   /* headings */
  --ink-soft:   #453E30;   /* body text */
  --ink-muted:  #8A7E64;   /* secondary, eyebrows, nav */
  --ink-light:  #B8AC8E;   /* footer, captions */
  --green:      #8FBF9F;   /* primary brand */
  --green-dark: #5A8C6E;   /* green text on light bg */
  --green-lt:   #EAF4EE;   /* green wash */
  --coral:      #C96B47;   /* wellbeing tool accent, alerts, Stage 3 */
  --coral-lt:   #FAE8E0;
  --gold:       #D4A843;   /* CTA buttons */
  --gold-lt:    #FDF5D0;
  --gold-dark:  #B8902E;
  --border:     rgba(28,26,20,0.08);
}
```

Audit the whole file: any hex value not in this list gets mapped to its nearest token.

---

## JOB 2 — Styling fixes

Known problems to fix in the current live page:

### 2a. Misaligned sentences
Several text blocks sit off-grid — some centred, some left, inconsistently within
the same section. Rule:
- Hero, section intros, CTA blocks: **centred**, `max-width: 640px; margin: 0 auto;`
- Card content, stage cards, feature lists: **left-aligned** inside the card
- Never mix alignments within one section. Audit every section against this rule.
- Body copy `line-height: 1.7`. Headings `line-height: 1.15–1.25`. No orphan
  single-word last lines on headings — add `&nbsp;` between final two words where needed.

### 2b. Age groups not clearly displayed on stage cards
The stage cards must use this exact hierarchy (this is the locked pattern):

```
[STAGE BADGE]  STAGE 3 · EXPLORER                ← eyebrow, 10px caps, ink-muted
KS2/KS3 · Year 6–8                               ← PRIMARY, Fraunces bold 20px, ink
Ages 11–13                                        ← secondary, DM Sans 14px, ink-soft
(US: Grades 6–8)                                  ← tiny, 11px, ink-light
─────────────
One-line focus statement                          ← 14px ink-soft
Device recommendation                             ← italic, ink-muted
```

UK Key Stage + Year Group is the bold primary line. Ages secondary. US grades
small and light. Stage 3 card gets a coral left border and a "Critical Window" pill.
All five cards identical structure, identical padding (20px), identical corner
radius (10px), aligned to a consistent grid — currently they drift.

### 2c. General polish
- One gold CTA style site-wide: `background: var(--gold); color: var(--ink);
  border-radius: 100px; font: 700 13px var(--sans); letter-spacing: 0.05em;
  text-transform: uppercase; padding: 14px 30px;`
- Consistent section padding: `padding: 72px 24px` desktop, `48px 20px` mobile
- Max content width 1080px, centred
- Policy badges (Online Safety Act / RSE / DfE / Ofcom) identical pill style as
  the wellbeing page

---

## JOB 3 — Linkable section URLs (including Teachers)

Every major section needs its own clean URL so Justin can deep-link from
LinkedIn, emails, and Instagram. Two parts:

### 3a. Section anchors in index.html

Give each section a stable `id`:

```html
<section id="stages">    …Find Your Stage…
<section id="how">       …How It Works…
<section id="teachers">  …Teachers / Schools section…   ← rename id from "schools" to "teachers"
<section id="research">  …Research…
<section id="pricing">   …Pricing…
```

Add smooth scrolling: `html { scroll-behavior: smooth; }` and
`section { scroll-margin-top: 90px; }` so anchors don't hide behind the sticky nav.

Update all nav buttons and internal links to point at these ids.
Keep `#schools` working as a legacy alias: add `<a id="schools"></a>` just
inside the teachers section so old links don't break.

### 3b. Pretty URLs via vercel.json

Add these redirects so each section has a real shareable URL:

```json
"redirects": [
  { "source": "/teachers", "destination": "/#teachers", "permanent": false },
  { "source": "/schools",  "destination": "/#teachers", "permanent": false },
  { "source": "/stages",   "destination": "/#stages",   "permanent": false },
  { "source": "/pricing",  "destination": "/#pricing",  "permanent": false },
  { "source": "/how",      "destination": "/#how",      "permanent": false }
]
```

Result: `guidedchildhood.com/teachers` is the link Justin shares with schools;
it lands directly on the Teachers section. Same pattern for every section.
(When the Next.js build lands in Week 5, `/teachers` upgrades to a full page —
these redirects are removed then.)

---

## ACCEPTANCE CHECKLIST

```
[ ] Fraunces + DM Sans only; loaded once in <head>
[ ] All colours map to the token list; no stray hex values
[ ] Homepage visually consistent with /digitalwellbeing
[ ] No mixed text alignment within any section
[ ] All 5 stage cards: KS/Year bold primary, ages secondary, US grades tiny
[ ] Stage 3 coral border + Critical Window pill
[ ] All sections have ids; smooth scroll; 90px scroll-margin
[ ] /teachers /stages /pricing /how all resolve and land on the right section
[ ] Old #schools links still work
[ ] Mobile: nav wraps cleanly, cards stack, CTAs full width
[ ] Lighthouse: no layout shift from font loading (font-display: swap)
```
