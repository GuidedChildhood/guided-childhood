# SCRIPTS — All 17 Conversation Scripts

Format for every script in the dashboard:
- Number and title
- Stage badge (which stages this applies to)
- Context line (when to use this)
- SAY THIS — exact words, first person
- NOT THIS — what most parents say instead
- WHY IT WORKS — 2-3 sentences, the research basis
- DiGi connection — "Ask DiGi if you need help tailoring this"

Displayed in Good Inside format: green / coral / gold boxes.
Readable in 30 seconds. Actionable tonight.

---

## SCRIPT 01
**Title:** "Everyone else has one."
**Stages:** 2, 3
**Context:** When your child argues peer pressure for a phone or social media.

SAY THIS:
"Our family has a pathway. We are not against it — we are doing it at the right time for you. Not yet means not yet, not never."

NOT THIS:
"I do not care what everyone else has."

WHY IT WORKS:
The first answer gives your child something to hold onto with their friends. "We have a pathway" signals a considered decision, not an arbitrary rule. "Not yet" gives a horizon. "Not never" keeps the connection open.

---

## SCRIPT 02
**Title:** "Her mood drops every time she puts her phone down."
**Stages:** 3
**Context:** When you notice a pattern of low mood following phone use — particularly in girls aged 11-13.

SAY THIS:
"I noticed you seem a bit flat after your phone. Does it ever leave you feeling worse?"

NOT THIS:
"You are addicted to that thing."

WHY IT WORKS:
Dr Amy Orben at Cambridge identifies 11-13 as the peak vulnerability window for girls. The first question opens a conversation. The second one closes it — and teaches your child not to come to you next time something goes wrong.

---

## SCRIPT 03
**Title:** Introducing the bedroom rule.
**Stages:** 1, 2, 3, 4, 5
**Context:** Introducing device-free bedrooms for the whole family.

SAY THIS:
"We are all doing this as a family. My phone charges in the kitchen tonight. It is not about trust. It is about sleep — and I want to model that for you."

NOT THIS:
"Give me your phone. It charges in here from now on."

WHY IT WORKS:
The bedroom rule is twice as effective when the parent does it too. The first script removes the adversarial dynamic entirely. You are making a family decision together — not policing your child.

---

## SCRIPT 04
**Title:** "I think something is wrong online."
**Stages:** 3, 4
**Context:** When you have noticed something but need to open the conversation without triggering shutdown.

SAY THIS:
"I noticed something and I am not angry. I want to understand this with you — not fix it for you."

NOT THIS:
"Give me your phone. I am going through everything."

WHY IT WORKS:
Surveillance destroys the thing you most need to protect: your child's willingness to come to you. A child who knows they will not lose their phone for being honest tells you what is actually happening.

---

## SCRIPT 05
**Title:** The algorithm conversation.
**Stages:** 2, 3
**Context:** The most important digital literacy conversation you can have. Have it before they use social media unsupervised.

SAY THIS:
"What do you think the app is trying to do? ... Close. It is trying to keep you watching. Those are different things. Watch — I will show you. [Search for something. Come back an hour later. Show them how the recommendations have changed.] That happened in one hour. Imagine what it knows after a year."

NOT THIS:
"Stop watching YouTube — it is rotting your brain."

WHY IT WORKS:
Once a child understands the algorithm is engineered to keep them watching, they are not a passive user anymore. They are someone who knows what is happening. That understanding is more protective than any rule.

---

## SCRIPT 06
**Title:** When your child cannot stop even when they want to.
**Stages:** 2, 3, 4
**Context:** When stopping is genuinely hard — not defiance, but difficulty with impulse regulation.

SAY THIS:
"Stopping is hard for everyone. The app is designed that way. That is not a flaw in you — it is engineering. Let's build a stopping signal together that works for you."

NOT THIS:
"You have no self-control."

WHY IT WORKS:
The American Academy of Pediatrics recommends joint problem-solving for children who struggle to disengage — particularly neurodivergent children. Naming the design mechanic removes shame and creates joint ownership of the solution.

---

## SCRIPT 07
**Title:** When they see something upsetting online.
**Stages:** 2, 3, 4, 5
**Context:** Your child has encountered disturbing content — dark web, self-harm, extreme content.

SAY THIS:
"Tell me what you saw. You are not in trouble. I want to understand it with you — not fix it for you."

NOT THIS:
"Why were you looking at that? Give me your phone right now."

WHY IT WORKS:
The most important thing you can build is the habit of coming to you when something goes wrong. That habit is built — or destroyed — in moments like this one.

---

## SCRIPT 08
**Title:** The social comparison conversation.
**Stages:** 3, 4
**Context:** When your child is comparing themselves — their life, body, achievements — to what they see online.

SAY THIS:
"I want to show you something. [Open their Instagram feed.] Every photo here — what do you think their actual week looked like? What did they leave out?"

NOT THIS:
"None of that is real."

WHY IT WORKS:
Abstract statements about "not real" do not land with adolescents. The curated life exercise — examining a specific feed together — makes the mechanism visible. Once they see it, they cannot unsee it.

---

## SCRIPT 09
**Title:** My child is being harassed or bullied online.
**Stages:** 2, 3, 4, 5
**Context:** When your child discloses online harassment or you discover it.

SAY THIS:
"I am glad you told me. What is happening to you is not okay and it is not your fault. We are going to look at this together and I will follow your lead on what to do next."

NOT THIS:
"Give me your phone. I am reporting this right now."

WHY IT WORKS:
Giving your child agency in the response is critical. Taking over immediately — however well-intentioned — teaches them not to tell you next time. "I will follow your lead" keeps them in control and keeps them coming to you.

---

## SCRIPT 10
**Title:** My child is being harassed because of who they are.
**Stages:** 3, 4, 5
**Context:** Identity-based harassment — LGBTQ+, neurodiversity, race, religion.

SAY THIS:
"What you are experiencing is not okay and it is not your fault. Online community can be a really important place — and some people in it are genuinely harmful. Let's look at who is safe and how we block what is not."

NOT THIS:
"Maybe take a break from social media for a while."

WHY IT WORKS:
For LGBTQ+ youth especially, online community is often a lifeline — not a risk. Suggesting restriction disproportionately harms this group. The intervention is harassment protection and safe community guidance, not access limitation.

---

## SCRIPT 11
**Title:** When your neurodivergent child cannot manage their device use.
**Stages:** 2, 3, 4
**Context:** ADHD, autism, or sensory processing differences and screen use causing family conflict.

SAY THIS:
"I know stopping is genuinely harder for you than it is for some other kids. Your brain responds differently to this stuff — that is real. Let's figure out together what stopping looks like for you."

NOT THIS:
"Everyone else can do it. Why can't you?"

WHY IT WORKS:
Acknowledging neurological reality removes shame and opens collaboration. The American Academy of Pediatrics is clear: joint problem-solving outperforms restriction for neurodivergent children. This script does exactly that.

---

## SCRIPT 12
**Title:** Talking about AI — what it is and what it is not.
**Stages:** 3, 4, 5
**Context:** When your child is using AI chatbots, image generators, or AI tools.

SAY THIS:
"What can a real friend do that an AI chatbot never could? ... AI sounds human. It is not human. It has no memory between conversations. It has no feelings. It does not know you. What it does is predict what a helpful-sounding response looks like."

NOT THIS:
"Stop using AI — it makes you lazy."

WHY IT WORKS:
Children who understand what AI actually does are not deceived by it. The question — what can a real friend do that AI cannot? — opens a conversation about human connection that is more valuable than any restriction.

---

## SCRIPT 13
**Title:** The deepfake conversation.
**Stages:** 4, 5
**Context:** Before your child encounters AI-generated video or audio of real people.

SAY THIS:
"AI can now make a photorealistic video of anyone saying anything. It can clone a voice from three seconds of audio. Before you react to something shocking online — pause and ask: could this be AI? And here is our family code word for real emergencies — anything without the code word, call me directly."

NOT THIS:
"Do not believe anything you see online."

WHY IT WORKS:
The reflex — pause, question, verify — is the most important media literacy skill of the next decade. The family code word is practical protection against AI voice cloning, not just a conversation. It takes two minutes to set up.

---

## SCRIPT 14
**Title:** Talking about pornography.
**Stages:** 3, 4
**Context:** Before or after a child encounters online pornography — which most children in Stage 3 already have.

SAY THIS:
"I want to talk about something you have probably already seen online — and I want you to hear about it from me before you draw conclusions from it. Pornography online is not what sex is. It is a performance. It is written, directed, and produced. It teaches things about bodies and relationships that are not true. What questions do you have?"

NOT THIS:
"If I ever catch you watching that I will take your phone forever."

WHY IT WORKS:
Research is consistent: children who have the sex and pornography conversation with a parent before encountering it online have significantly better outcomes than those who do not. The threat response teaches them to hide it. The factual response keeps them coming to you.

---

## SCRIPT 15
**Title:** "Is it too late if they already have the phone?"
**Stages:** 2, 3, 4
**Context:** When a parent feels they have already missed the window and the child has full access.

SAY THIS:
"There are more school pickups ahead of you than behind you. More car journeys. More evenings. The pathway starts from wherever you are — not from wherever you wish you had started. Two things to do tonight: the bedroom rule, and one question: does your phone ever leave you feeling worse?"

NOT THIS:
[nothing — this script is for the parent, not to use with the child]

WHY IT WORKS:
Self-blame in parents reduces action. This reframe is evidence-based: the bedroom rule and the open question remain effective regardless of when they start. The pathway starts today.

---

## SCRIPT 16
**Title:** The vibe coding conversation.
**Stages:** 4, 5
**Context:** When your child is interested in building things online using AI tools.

SAY THIS:
"AI has made it possible for anyone to build things online without traditional coding. You have a problem you want to solve? We can find a tool that lets you build something. The most powerful people on the internet are the ones who create things, not just consume them."

NOT THIS:
"That is not a real skill."

WHY IT WORKS:
Stage 5 of Guided Childhood is about preparing children for full digital access — not just protecting them from it. A child who builds things online is developing agency, critical thinking, and a fundamentally different relationship with technology. This is the goal.

---

## SCRIPT 17
**Title:** When your child asks why the UK restrictions matter.
**Stages:** 3, 4
**Context:** When the UK government's age restriction debate is in the news and your child asks about it.

SAY THIS:
"Whether the restrictions pass or not, our family has a pathway. We are not against social media. We are making sure you are actually ready for it — not just old enough."

NOT THIS:
"Because the government says so."

WHY IT WORKS:
"Because the government says so" is compliance framing. It gives your child nothing to hold onto when the restrictions are challenged or changed. "We have a pathway" positions this as your family's considered approach — which it is. The pathway works regardless of legislation.
