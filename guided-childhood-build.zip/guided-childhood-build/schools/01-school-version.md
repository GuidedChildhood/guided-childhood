# SCHOOL VERSION SPECIFICATION

## Philosophy

The school version of Guided Childhood is not a separate product. It is the same research base, the same five stages, the same DiGi philosophy — delivered in the format UK schools actually use.

The benchmark is the Oak National Academy model: free, high quality, curriculum-aligned, ready to use without preparation. Every lesson plan in the school version is ready to pick up and deliver tomorrow.

---

## Oak National Academy Alignment

Oak National Academy (thenational.academy) is the UK government's free lesson resource provider. Schools trust it. Ofsted recognises it. The Guided Childhood scheme of work is designed to sit alongside Oak — complementing it on digital literacy where Oak's provision is thinner.

School version lessons are structured identically to Oak:
- Learning objective
- Starter activity (5 minutes)
- Main activity (30-35 minutes)
- Plenary (5-10 minutes)
- Exit ticket
- Homework / home connection (parent take-home)
- Teacher notes
- Slides (downloadable)
- Pupil worksheet (downloadable)

Every lesson has a **Parent Take-Home Note** — one page, plain language, connecting what was taught in school to what parents can do at home. This is the parent-school connection built into every lesson.

---

## Statutory Alignment

Every lesson explicitly maps to:

1. **Online Safety Act 2023** — platform duty requirements for education
2. **Statutory RSE and Health Education** — online safety components (compulsory from September 2020)
3. **Education for a Connected World (UKCIS 2020)** — all 8 framework strands
4. **DfE AI in Education Guidance 2025** — AI literacy content from KS3
5. **Ofsted** — evidence of online safety provision, downloadable mapping document

One downloadable document per school shows governor and Ofsted exactly which statutory requirement each lesson meets. This document is the thing a DSL prints for a governor meeting.

---

## Scheme of Work — 21 Half-Term Modules

### EYFS & KS1 (Year R–2, Ages 4–7)

**Module 1: Screens We Share**
Learning objective: Understand that screens are for sharing with adults.
Topics: Co-viewing, what we watch together, why we talk about what we see.
UKCIS strand: Online Relationships.

**Module 2: Real and Not Real**
Learning objective: Begin to distinguish between real life and screen content.
Topics: Cartoons vs real people, advertisements, what is made up.
UKCIS strand: Information Literacy.

**Module 3: Kind and Unkind Online**
Learning objective: Apply the same kindness rules online as offline.
Topics: Kind words, unkind words, what to tell a trusted adult.
UKCIS strand: Online Bullying.

---

### KS2 (Year 3–6, Ages 7–11)

**Module 4: How the Algorithm Works**
Learning objective: Understand that recommendation systems learn from behaviour.
Topics: What you click, what the app learns, why it shows you more of the same.
UKCIS strand: Information Literacy / Managing Online Information.

**Module 5: Privacy and Your Data**
Learning objective: Understand that personal data has value and risk.
Topics: What data is, who collects it, why privacy matters.
UKCIS strand: Privacy and Security.

**Module 6: Online Safety Foundations**
Learning objective: Know the key signs of unsafe contact and what to do.
Topics: Grooming signs, red flags, who to tell, disclosure.
UKCIS strand: Online Relationships / Self-Image.

**Module 7: The Internet You Do Not See**
Learning objective: Understand the structure of the internet.
Topics: Surface web, what exists beyond it, why some content is dangerous.
UKCIS strand: Information Literacy.

**Module 8: Gaming and Friendships**
Learning objective: Understand the line between healthy gaming and problematic use.
Topics: Gaming as social space, unknown contacts in games, in-app purchases.
UKCIS strand: Online Relationships / Health Wellbeing and Lifestyle.

---

### KS3 (Year 7–9, Ages 11–14)

**Module 9: Social Media and the Brain**
Learning objective: Understand why social media affects mood and self-image.
Topics: Variable reward, body image algorithm, comparison culture, Orben research.
UKCIS strand: Health Wellbeing and Lifestyle / Self-Image.

**Module 10: AI — What It Is and Is Not**
Learning objective: Understand the difference between AI and human intelligence.
Topics: How LLMs work, AI chatbots, what AI cannot do, voice cloning, deepfakes.
UKCIS strand: Information Literacy / Online Safety.
DfE AI alignment: Direct.

**Module 11: The Dark Web and Online Risk**
Learning objective: Understand that some areas of the internet carry genuine risk.
Topics: Dark web basics, why it exists, what the risks are, what to do if you encounter something.
UKCIS strand: Online Safety / Managing Online Information.

**Module 12: Online Safety — Advanced**
Learning objective: Recognise and respond to grooming, sextortion, and manipulation.
Topics: Escalation patterns, what to do if it happens to you, who to tell, no blame.
UKCIS strand: Online Relationships / Online Safety.
Safeguarding: Full DSL guidance in teacher notes.

**Module 13: Your Digital Reputation**
Learning objective: Understand that digital reputation is permanent and significant.
Topics: What employers/universities see, screenshots last forever, repairing digital reputation.
UKCIS strand: Self-Image and Identity.

---

### KS4 (Year 10–11, Ages 14–16)

**Module 14: Manipulation, Radicalisation, and Extremism**
Learning objective: Recognise the patterns of online manipulation.
Topics: Filter bubbles, radicalisation pipeline, conspiracy content, how to interrupt it.
UKCIS strand: Online Safety / Managing Online Information.
Safeguarding: Full DSL guidance. Counter-terrorism framework alignment.

**Module 15: Sextortion and Image-Based Abuse**
Learning objective: Understand what sextortion is and what to do.
Topics: How it happens, legal protections, what to do, who to tell, no shame.
UKCIS strand: Online Relationships / Online Safety.
Safeguarding: Full DSL escalation protocol.

**Module 16: AI Literacy and Critical Thinking**
Learning objective: Apply critical thinking to AI-generated content.
Topics: Deepfakes, synthetic media, fact-checking, AI in daily life.
UKCIS strand: Information Literacy / Managing Online Information.
DfE AI alignment: Direct.

**Module 17: Data Rights and Privacy — Advanced**
Learning objective: Exercise rights over personal data.
Topics: GDPR, data subject rights, how to request deletion, data brokers.
UKCIS strand: Privacy and Security.

---

### KS5 (Year 12–13, Ages 16–18)

**Module 18: AI Mastery — Building With AI**
Learning objective: Use AI tools productively and critically.
Topics: Vibe coding, AI for study and work, intellectual property, AI in careers.
UKCIS strand: Information Literacy.
DfE AI alignment: Future national curriculum preparation.

**Module 19: Digital Wellbeing in Higher Education**
Learning objective: Manage digital life through transitions.
Topics: University digital culture, social media and mental health in HE, managing distraction.
UKCIS strand: Health Wellbeing and Lifestyle.

**Module 20: Security, Privacy, and Professional Digital Life**
Learning objective: Apply professional standards to digital conduct.
Topics: Professional social media, email security, data protection at work.
UKCIS strand: Privacy and Security.

**Module 21: The Internet You Will Help Build**
Learning objective: Understand the role of a digital citizen in shaping the internet.
Topics: Building things online, ethical tech, what the internet could be.
UKCIS strand: All strands — capstone module.

---

## CPD Module for Staff

One standalone CPD session for all teaching staff.

Structure:
1. The research overview (30 minutes) — what the evidence actually says about children and social media
2. Safeguarding and digital risk (30 minutes) — online grooming, sextortion, radicalisation, escalation pathways
3. Supporting parents through digital challenges (30 minutes) — how to have the conversation with a parent who comes to you worried
4. The neurodivergent child and digital use (15 minutes) — tailored approaches
5. AI in the classroom (15 minutes) — what the DfE says and what to do

Downloadable: Full CPD slide deck. Facilitator notes. Staff digital charter template.

---

## DSL Safeguarding View

A dedicated view in the educator dashboard for the Designated Safeguarding Lead.

Shows:
- Any student whose DiGi or wellbeing tracker has triggered a high concern flag (anonymised unless DSL has permission)
- Suggested escalation pathways
- Referral templates (CAMHS, NSPCC, Childline, local authority)
- Legal framework reference — what the school's obligations are
- Module 12 and 15 delivery notes — safeguarding-sensitive content guidance

GDPR compliance: Full data protection documentation. No individual student data shared without explicit consent and appropriate permissions.

---

## Parent-School Connection

The school version includes a parent engagement layer:

**Parent evening pack:**
- Slide deck (45 minutes, with speaker notes)
- Parent take-home sheet for each Key Stage
- QR code linking to guidedchildhood.com/starter-pack

**Parent letters:**
- Before each module runs, parents receive a one-page letter explaining what will be covered, why, and what to continue at home
- Three versions: Primary, Lower Secondary, Upper Secondary

**School-platform link:**
- If parents are also on the Guided Childhood parent platform, their child's stage matches the school scheme
- DiGi knows which modules the child has covered at school

---

## Pilot Scheme — Full Specification

The pilot scheme is the primary conversion mechanism for schools.

### What a Pilot Includes

```
Duration: One full term (10-12 weeks)
Cost: Free

Week 1: Onboarding call (30 minutes) — scheme setup, staff briefing
Weeks 2-11: Full access to all 21 modules for selected year groups
Week 4: Mid-pilot check-in call (15 minutes)
Week 12: Review call (30 minutes) — outcomes, data, next steps

Included:
- Full educator dashboard access
- Selected modules printed and digital
- CPD session for PSHE/Computing staff (90 minutes)
- Parent evening delivery support
- DSL safeguarding briefing
- Full statutory alignment document

Not included in free pilot:
- Whole-school licence
- Unlimited module access
- School-branded materials
- Additional staff training
```

### Pilot CTA — School Marketing Page

```
SECTION HEADLINE:
"Start with a free pilot scheme"

BODY:
We work with a small number of schools each term to implement Guided 
Childhood with full support. The pilot gives you everything you need to 
evaluate the scheme — including a term's full access, CPD for your team, 
and a parent evening pack. No commitment required. One conversation to see 
if it fits.

WHAT YOU GET IN THE PILOT:
✓ Full term access — selected year groups
✓ 90-minute CPD session for your PSHE and Computing team
✓ Parent evening pack and delivery support
✓ DSL safeguarding briefing
✓ Full statutory alignment document for governors
✓ Review call at the end of the term

WHO THIS IS FOR:
DSLs, PSHE leads, and headteachers who want to see the scheme working 
in their school before committing.

FORM FIELDS:
- School name
- Your name
- Your role (DSL / PSHE Lead / Head / Other)
- School email
- Pupil numbers (dropdown: under 200 / 200-400 / 400-600 / 600+)
- Best time to talk (dropdown)
- Anything specific you want the pilot to address (optional)

BUTTON: "Request a pilot meeting"

CONFIRMATION MESSAGE:
"Thank you. We will be in touch within 48 hours to schedule a 
30-minute call. We take on a small number of schools each term so 
we can support each one properly."

FOLLOW-UP EMAIL (sent immediately):
Subject: "Your Guided Childhood pilot request — [School Name]"
From: Justin Phillips
Body: Personal, warm. Confirms the request. Sets expectation for 48-hour response. 
Links to guidedchildhood.com/schools for more information.
```

### Pilot Conversion Path

```
1. School visits /schools or educator is referred
2. Clicks "Request a pilot meeting"
3. Completes form → Supabase school_profiles table (pilot_requested = true)
4. Admin notification sent to Justin
5. Automated email to school within 2 minutes
6. Justin contacts within 48 hours to schedule
7. 30-minute call — needs assessment, school context, timeline
8. Pilot agreement sent (PDF)
9. School confirmed → pilot_status = 'active'
10. Educator dashboard access unlocked for term
11. Review at end of term → conversion to paid licence
```
