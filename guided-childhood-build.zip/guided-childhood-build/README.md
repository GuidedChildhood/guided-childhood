# GUIDED CHILDHOOD — CLAUDE CODE BUILD SPECIFICATION
## Version 1.0 — Starter Platform

**Founded by:** Justin Phillips, The Social Billboard, Bath UK  
**Domain:** guidedchildhood.com  
**Model:** Good Inside (goodinside.com) — benchmark for design, UX, and conversion  
**Stack:** Next.js 14 · Supabase · Stripe · Anthropic API · Vercel  

---

## READ THIS FIRST

This folder contains everything Claude Code needs to build the Guided Childhood platform.
Read every file before writing a single line of code.
The order matters.

```
/docs/          — Architecture, database, routes, auth
/digi/          — DiGi AI engine, philosophy, system prompt
/curriculum/    — Five stages, all content, scripts, guides
/scripts/       — All 17 conversation scripts
/research/      — Science base, philosophy, key researchers
/schools/       — School version, Oak-aligned curriculum
```

---

## WHAT WE ARE BUILDING

Two versions of the same platform, sharing one codebase:

**Version A — Parent Platform** (primary)
A staged digital parenting pathway for children aged 4–16.
Five developmental stages. Weekly actions. DiGi AI advisor.
Wellbeing tracker. Scripts. Curriculum. Paywall at Stage access.

**Version B — School Platform** (secondary)
Same research base, school delivery format.
Oak National Academy aligned scheme of work.
DSL and PSHE lead dashboard. Parent-school connection.
Pilot scheme CTA replacing standard signup.

---

## BUILD SEQUENCE

Build in this exact order. Each week delivers something live.

**Week 1 — Shell + Auth**
Next.js setup. Supabase auth. Login/signup with email+password.
Homepage rebuilt from existing index.html.
All routes defined. Vercel deployment.

**Week 2 — Parent Dashboard + DiGi**
Parent onboarding (3 questions — same as mini app).
Stage assignment. DiGi live with full system prompt.
Basic dashboard with stage card and weekly actions.
Paywall placeholder.

**Week 3 — Scripts + Curriculum**
All 17 scripts in dashboard.
Stage curriculum — Units 1–4 per stage as starter.
Family agreement builder.
Wellbeing tracker v1.

**Week 4 — Stripe + Paywall**
Free tier: onboarding, DiGi 3 questions/day, Stage 1 content only.
Paid tier: all stages, unlimited DiGi, all scripts, tracker.
Founder rate: £7.99/month lifetime, first 50.
Standard: £12.99/month.

**Week 5 — School Version**
School signup flow (school email validation).
Educator dashboard with scheme of work.
DSL safeguarding view.
Pilot scheme CTA and meeting request form.

**Week 6 — Mental Health Checker Link + Polish**
Link from dashboard to Digital Wellbeing tool.
Question history. Referral routing.
Mobile optimisation. Admin panel.
Soft launch to founder waitlist.

---

## CRITICAL DESIGN RULES

1. **Never output allow/deny.** DiGi always returns a calibrated pathway, never permission.
2. **Build behind demand.** No feature until conversion signals justify it.
3. **Good Inside is the design benchmark.** Every UI decision measured against goodinside.com.
4. **Use the frontend-design skill.** No generic AI web design. Distinctive, intentional, warm.
5. **Justin's voice throughout.** All copy through the human-voice skill. No AI-isms.
6. **DiGi stands alone.** DiGi is a distinct product within Guided Childhood, not a chatbot.

---

## ENVIRONMENT VARIABLES NEEDED

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_KEY=
ANTHROPIC_API_KEY=
STRIPE_SECRET_KEY=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_WEBHOOK_SECRET=
NEXT_PUBLIC_APP_URL=https://guidedchildhood.com
```

---

## COLOUR SYSTEM (exact — checker-aligned, never deviate)

The homepage, starter packs, and Digital Health Checker all share one design system.
This is the official system for the platform build.

```css
--cream:      #F7F3EE   /* main bg */
--warm:       #FDFBF8   /* section alt / cards */
--ink:        #1C1C1C   /* primary text */
--ink-soft:   #4A4A4A   /* body text */
--ink-muted:  #6E6A62   /* secondary text */
--ink-light:  #9B958A   /* captions */
--green:      #AFDCA2   /* brand green block */
--green-dark: #2E7D5A   /* green text / accents */
--green-lt:   #EEF7F2   /* wash */
--coral:      #D4600A   /* alerts, Stage 3 critical */
--coral-lt:   #FEF3E8   /* wash */
--coral-dark: #C0392B   /* critical deep */
--gold:       #F2C94C   /* primary CTA yellow */
--gold-lt:    #FEFAE8   /* wash */
--gold-dark:  #C9962A   /* gold text */
--gold-hover: #E3B53A   /* CTA shadow / hover */
--lav:        #E7ECF8   /* lavender accent */
--lav-deep:   #3D5BA9   /* lavender text */
--border:     #E4DFD7
```

Signature components: chunky 16px-radius CTA buttons with hard `0 5px 0` drop
shadow, IBM Plex Mono eyebrow labels at .16em tracking, Hanken Grotesk 800 display.

## TYPOGRAPHY

```
Display/headings: Hanken Grotesk 700–800 (Google Fonts)
Body: Hanken Grotesk 400–600
Labels/eyebrows/buttons/data: IBM Plex Mono 400–600
```

---

## START HERE

Open `/docs/01-architecture.md` and read the full stack specification.
Then `/docs/02-database.md` for the Supabase schema.
Then `/docs/03-routes.md` for all application routes.
Then `/digi/01-philosophy.md` for the DiGi engine.
Then `/docs/06-starter-pack-funnel.md` for the pre-paywall funnel architecture.

Do not write code until you have read all four files.
