# RESEARCH FOUNDATION & PHILOSOPHY

## The Core Thesis

Everything in Guided Childhood — every script, every stage decision, every DiGi response — flows from one intellectual position:

**The platform does not create the vulnerability. It detects it.**

Children arrive on platforms carrying something — a developing brain at a sensitive window, a pre-existing mental health condition, body image concerns, a neurodivergent profile, economic precarity, an identity under social threat. The algorithm finds it. Then it amplifies it.

The protection is not removing the platform. It is reducing the vulnerability the platform can find.

This is the foundational insight that makes Guided Childhood different from every other digital parenting product. We are not anti-technology. We are not pro-restriction. We are pro-pathway.

---

## The Five Developmental Stages

Derived from: UKCIS Education for a Connected World, UK Key Stage framework, Orben developmental windows research, AAP guidance.

### Stage 1 — Foundation
**EYFS & KS1 · Year R–2 · Ages 4–7**

Key insight: Habits formed at age 4-7 are the habits that persist at 13. The foundation stage is not about restriction — it is about establishing co-viewing, shared experience, and the principle that technology is a family activity, not a solo one.

Research basis: Sonia Livingstone's work on parental mediation. AAP shared media time recommendations. Ofcom data showing 1 in 5 children aged 3-5 already have their own mobile phone.

DiGi context: Focus on co-viewing conversations. Help parents talk about what they see together. Introduce the concept that devices are for the family, not individuals.

### Stage 2 — First Steps
**KS2 · Year 3–5 · Ages 8–10**

Key insight: The algorithm conversation must happen before unsupervised use. Privacy basics. The difference between "showing you what you like" and "keeping you watching."

Research basis: Przybylski Goldilocks effect. Livingstone on digital skills. UKCIS pillar: privacy and security.

DiGi context: The algorithm conversation. Privacy conversations. First experiences of content that surprises or disturbs. Gaming as first platform exposure.

### Stage 3 — Explorer (Critical Window)
**KS2/KS3 · Year 6–8 · Ages 11–13**

Key insight: Amy Orben's Cambridge research is the most important single finding for this stage. Girls aged 11-13 experience the highest vulnerability to social media's negative mental health effects. Brain development and social identity formation intersect with peak platform use. This is the stage that matters most.

Research basis: Orben et al 2019 Nature Human Behaviour. JAMA Pediatrics 2024 (30min/day reduction). US Surgeon General Advisory 2023. Who Is Actually Being Harmed 2026.

DiGi context: Body image. Social comparison. The bedroom rule. Mood tracking. Opening difficult conversations. This stage has the most DiGi usage — parents need support most here.

Specific risks this stage:
- Appearance-comparison algorithm (girls)
- Sleep disruption from bedroom device use
- Social media introduction — peer pressure
- First experiences of distressing content
- Algorithm locking in based on vulnerable searches

### Stage 4 — Navigator
**KS3/KS4 · Year 9–10 · Ages 13–15**

Key insight: Guided access, not full access. Digital reputation is permanent. Filter bubbles. Readiness for 16.

Research basis: Livingstone on agency. Ofcom data on adolescent platform use. ICO Children's Code on age assurance.

DiGi context: Reputation, filter bubbles, data rights, guided social media use, AI chatbot awareness, dark web awareness.

### Stage 5 — Independent
**KS4/KS5 · Year 11+ · Ages 16+**

Key insight: The goal of the entire pathway. A child who arrives at 16 genuinely ready for full digital access — not at a cliff edge. AI literacy, data rights, vibe coding.

Research basis: DfE AI Guidance 2025. Ofcom data on platform use by 16+. Academic research on media production vs consumption.

DiGi context: AI mastery, data rights, deepfakes, vibe coding, privacy at university, preparing for adult digital life.

---

## The Six At-Risk Groups

Source: Who Is Actually Being Harmed, 2026. Evidence-Based Analysis.

These groups are not the target audience. All children benefit from Guided Childhood. These groups need it most urgently.

### 1. Adolescent Girls, Ages 11–15
- 1 in 4 say social media hurt their mental health (vs 1 in 7 boys)
- 1 in 3 girls aged 11-15 say they feel addicted to a platform
- Healthcare visits for eating disorders more than doubled 2018-2022 (under 17)
- Orben: 11-13 is the peak vulnerability window for this group
- Mechanism: appearance comparison algorithm

Platform response: Stage 3 onboarding flags if child is a girl aged 11-15. DiGi prioritises body image and comparison content. Wellbeing tracker adds optional body image question.

### 2. Children with Pre-existing MH Conditions
- Surgeon General advisory: higher relative concern for this group
- Algorithm amplifies distress signal — search depression, see more depression
- King's College London 2022: triggers and reinforces symptom cycles

Platform response: Optional MH flag at onboarding lowers DiGi concern threshold. Wellbeing tracker adds additional question. Referral routing earlier.

### 3. LGBTQ+ Youth
- Trevor Project 2023: 67% report anxiety symptoms, 54% depression
- Significantly more high-risk online interactions
- CRITICAL: online community is often a lifeline, not a risk
- Over 90% of US transgender youth live in states restricting gender-affirming care — online community is sometimes the only safe space
- Intervention: harassment reduction and safe community, NOT restriction

Platform response: No direct LGBTQ+ flag (could out children to parents). Harassment flag instead. DiGi NEVER suggests restriction for this group. Scripts 09, 10 apply.

### 4. Neurodivergent Children
- ADHD: higher risk for screen-related difficulties, impulse regulation
- High sensory curators: 4x more likely to experience digital media conflict
- Standard digital safety education fails this group (designed for neurotypical cognition)
- AAP recommendation: joint problem-solving, not restriction

Platform response: Optional neurodivergent flag. DiGi adjusts to concrete language and joint problem-solving approach. Script 11 applies. No shame framing ever.

### 5. Children from Low-Income Backgrounds
- 3+ hours daily: 2x risk of poor mental health
- Less parental mediation, more unsupervised use, fewer offline alternatives
- School-based digital literacy is the most scalable intervention for this group

Platform response: School product specifically positioned for this. Free assembly pack. School licence pricing designed for any budget.

### 6. Children Ages 10–13: The Developmental Window
- Existential social belonging. Most malleable identity. Brain reward systems most sensitive.
- JAMA Pediatrics 2024: 30 min daily reduction = significant MH improvement, strongest effect here
- This is Stage 3 — the entire stage is designed for this window

---

## The TRUST Framework

The five principles that run through every piece of Guided Childhood content:

**T — Timing matters more than restriction**
The age of first access, the developmental stage, the readiness — these matter more than whether access happens at all.

**R — Relationship is the protection**
A child who will talk to a parent is more protected than a child with a screen time app. Every action builds the relationship.

**U — Understanding the algorithm**
Children who understand how recommendation systems work are not passive users. Digital literacy is the protection.

**S — Structure over surveillance**
The bedroom rule, the family agreement, the conversation habits — these are structures that reduce vulnerability. Surveillance destroys trust and teaches hiding.

**T — Transition to independence**
The goal of the entire system is a child who arrives at 16 genuinely ready for full digital access. Every stage builds toward this.

---

## Good Inside Model (Benchmark)

Guided Childhood models itself on Good Inside by Dr Becky Kennedy:

- **Content first** — free content drives membership, not the other way around
- **One consistent framework** — not random tips, but one coherent approach
- **Scripts and tools** — practical, specific, actionable
- **Personal voice** — Justin's story, not corporate content
- **AI as extension** — DiGi as GiGi equivalent, but for digital parenting
- **Staged growth** — content → membership → app, always behind demand

Key differences from Good Inside:
- UK-focused legislation and framework alignment
- Research is more specific and recent (Orben 2019-2024, JAMA 2024)
- School version integrated from day one
- The six at-risk groups explicitly addressed
- Developmental window more precisely defined

---

## What Guided Childhood Never Says

- "Social media is bad for all children"
- "Smartphones should be banned"
- "Your child is at risk"
- "Get rid of the phone"
- Anything that positions parents as failing
- Anything that positions restriction as the answer
- Anything that ignores the protective value of online community for isolated children

---

## What Guided Childhood Always Says

- Children need a pathway, not a ban
- The cliff edge — unsupervised access with no preparation — is the risk
- Structure protects. Conversation protects. Relationship protects.
- Every stage builds toward genuine readiness at 16
- It is not too late to start from wherever you are
